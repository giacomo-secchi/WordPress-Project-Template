<?php // phpcs:ignore Internal.NoCodeFound ?>
{{schema name="yoast/job-location-city" only-nested=true}}
{{html name="city"}}
