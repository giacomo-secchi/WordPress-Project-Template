<?php // phpcs:ignore Internal.NoCodeFound ?>
{{schema name="yoast/job-location-postal-code" only-nested=true}}
{{html name="postal-code"}}
